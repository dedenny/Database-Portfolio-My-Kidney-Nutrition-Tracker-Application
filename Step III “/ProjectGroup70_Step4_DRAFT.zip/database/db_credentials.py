host = 'localhost'
user = 'cs340_dev'                                   # can be different if you set up another username in your MySQL installation
passwd = 'password'                        # set accordingly
db = 'kidney'